﻿using System.Collections.Generic;

namespace Sketch2Code.Core.BoxGeometry
{
    public enum ProjectionAxisEnum
    {
        X,Y
    }

    public class ProjectionRuler
    {
        public List<Section> Sections = new List<Section>();
    }
}