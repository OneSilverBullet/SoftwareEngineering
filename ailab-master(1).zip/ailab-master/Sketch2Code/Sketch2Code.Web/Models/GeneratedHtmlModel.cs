﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Sketch2Code.Web.Models
{
    public class GeneratedHtmlModel
    {
        public string Html;
        public string FolderId;
        public string GeneratedHtmlImageUrl;

    }
}